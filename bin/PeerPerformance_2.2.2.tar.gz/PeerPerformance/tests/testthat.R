library(testthat)
library(PeerPerformance)

test_check("PeerPerformance")
